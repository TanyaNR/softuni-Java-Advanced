package OOP.O1_Abstract.E01_CardSuit;

public enum CardSuite {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;
}
