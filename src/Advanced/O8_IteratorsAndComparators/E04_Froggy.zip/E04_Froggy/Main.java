package O8_IteratorsAndComparators.E04_Froggy;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

        List<Integer> indexes = Arrays.stream(bufferedReader.readLine().split(", ")).map(Integer::parseInt).collect(Collectors.toList());
        String command = bufferedReader.readLine();

        Lake lake = new Lake(indexes);

        StringBuilder stringBuilder = new StringBuilder();


        for (Integer index : lake) {
            stringBuilder.append(index).append(", ");
        }

        String output = stringBuilder.substring(0, stringBuilder.length() - 2);

        System.out.println(output);
    }
}
