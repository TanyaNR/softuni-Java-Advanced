package O6_DefiningClasses.E_07_Google;

public class Pokemon {

    //pokemon {pokemonName} {pokemonType}
    private String pokemonName;
    private String pokemonType;

    public Pokemon(String pokemonName, String pokemonType) {
        this.pokemonName = pokemonName;
        this.pokemonType = pokemonType;
    }

    @Override
    public String toString() {
        return pokemonName + " " + pokemonType;
    }
}
